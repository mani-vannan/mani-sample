﻿namespace LogoApp
{
    partial class LogoAppForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.txtBoxURL = new System.Windows.Forms.TextBox();
            this.lblURL = new System.Windows.Forms.Label();
            this.btnSubmitURL = new System.Windows.Forms.Button();
            this.lblLogoText = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.Location = new System.Drawing.Point(104, 206);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Size = new System.Drawing.Size(154, 139);
            this.picBoxLogo.TabIndex = 0;
            this.picBoxLogo.TabStop = false;
            // 
            // txtBoxURL
            // 
            this.txtBoxURL.Location = new System.Drawing.Point(104, 67);
            this.txtBoxURL.Name = "txtBoxURL";
            this.txtBoxURL.Size = new System.Drawing.Size(154, 20);
            this.txtBoxURL.TabIndex = 1;
            // 
            // lblURL
            // 
            this.lblURL.AutoSize = true;
            this.lblURL.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblURL.Location = new System.Drawing.Point(68, 68);
            this.lblURL.Name = "lblURL";
            this.lblURL.Size = new System.Drawing.Size(35, 19);
            this.lblURL.TabIndex = 2;
            this.lblURL.Text = "URL";
            // 
            // btnSubmitURL
            // 
            this.btnSubmitURL.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitURL.Location = new System.Drawing.Point(119, 102);
            this.btnSubmitURL.Name = "btnSubmitURL";
            this.btnSubmitURL.Size = new System.Drawing.Size(75, 23);
            this.btnSubmitURL.TabIndex = 3;
            this.btnSubmitURL.Text = "Submit";
            this.btnSubmitURL.UseVisualStyleBackColor = true;
            this.btnSubmitURL.Click += new System.EventHandler(this.btnSubmitURL_Click);
            // 
            // lblLogoText
            // 
            this.lblLogoText.AutoSize = true;
            this.lblLogoText.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogoText.Location = new System.Drawing.Point(152, 172);
            this.lblLogoText.Name = "lblLogoText";
            this.lblLogoText.Size = new System.Drawing.Size(0, 23);
            this.lblLogoText.TabIndex = 4;
            // 
            // LogoAppForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 357);
            this.Controls.Add(this.lblLogoText);
            this.Controls.Add(this.btnSubmitURL);
            this.Controls.Add(this.lblURL);
            this.Controls.Add(this.txtBoxURL);
            this.Controls.Add(this.picBoxLogo);
            this.Name = "LogoAppForm";
            this.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.Text = "LogoAppForm";
            this.Load += new System.EventHandler(this.LogoAppForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.TextBox txtBoxURL;
        private System.Windows.Forms.Label lblURL;
        private System.Windows.Forms.Button btnSubmitURL;
        private System.Windows.Forms.Label lblLogoText;
    }
}

