﻿using System;
using System.Windows.Forms;
using System.Net;
using System.IO;
//using System.DirectoryServices;


namespace LogoApp
{
    public partial class LogoAppForm : Form
    {
        public LogoAppForm()
        {
            InitializeComponent();
        }
        
        private void btnSubmitURL_Click(object sender, EventArgs e)
        {

            var tbURL = txtBoxURL.Text;
            var domain = new Uri(tbURL).GetLeftPart(UriPartial.Authority).Replace("https://","").Replace("/www.", "/").Replace("http://", "").Replace("www.","");
            lblLogoText.Text = domain.ToString();

            //Uri newUri = new Uri(tbURL);
            //Uri newUri = ActualUri.GetLeftPart(UriPartial.Authority).Replace("www.","");

            //MessageBox.Show("Absolute Uri: " + newUri.AbsoluteUri + "| Authority: " + newUri.Authority +"| DnsSafeHost: "+ newUri.DnsSafeHost + "| Host: " + newUri.Host );

            string fileName = domain.ToString() + ".jpeg";
            string filePath = Path.Combine("C:/", fileName);

            string url = "https://logo.clearbit.com/" + domain;


            HttpWebRequest Request = (HttpWebRequest)WebRequest.Create(@url);
            Request.Proxy.Credentials = CredentialCache.DefaultCredentials;


            String lsResponse = string.Empty;
            try
            {
                HttpWebResponse Response = (HttpWebResponse)Request.GetResponse();
                using (Response)
                {
                    using (BinaryReader reader = new BinaryReader(Response.GetResponseStream()))
                    {
                        Byte[] lnByte = reader.ReadBytes(1 * 1024 * 1024 * 10);

                        using (FileStream lxFS = new FileStream(filePath, FileMode.Create))
                        {
                            lxFS.Write(lnByte, 0, lnByte.Length);
                        }
                    }
                }
            }

            catch (WebException)
            {
                MessageBox.Show("Wrong Input! Please spell-check!");
                this.Refresh();
                picBoxLogo.Refresh();
            }

            finally { }

            picBoxLogo.ImageLocation = filePath;
        }

        private void LogoAppForm_Load(object sender, EventArgs e)
        {

        }
    }
}
